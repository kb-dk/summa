package org.marc4j.converter.impl;

public interface CodeTableInterface
{
    public boolean isCombining(int i, int g0, int g1);
    public char getChar(int c, int mode);
};
