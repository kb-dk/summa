/*
 * The State and University Library of Denmark
 * CVS:  $Id: FakeClient.java,v 1.1 2007/06/11 14:21:39 te Exp $
 */
package dk.statsbiblioteket.summa.score.server.deploy;

import java.rmi.RemoteException;
import java.net.URL;
import java.util.List;
import java.util.ArrayList;

import dk.statsbiblioteket.summa.score.api.ClientConnection;
import dk.statsbiblioteket.summa.score.api.Status;
import dk.statsbiblioteket.summa.common.configuration.Configuration;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class FakeClient implements ClientConnection {
    private Log log = LogFactory.getLog(FakeClient.class);

    public FakeClient(Configuration configuration) {
        log.info("Got created");
    }

    public Status stop() throws RemoteException {
        log.info("Stop called");
        return new Status(Status.CODE.stopped, "Fake status says stopped");
    }

    public Status getStatus() throws RemoteException {
        log.info("Status called");
        return new Status(Status.CODE.running, "Fake status");
    }

    public void deployService(String id, URL packageLocation,
                              Configuration configuration) throws RemoteException {
        log.info("Fake deploying " + id + " from location " + packageLocation);
    }

    public void startService(String id,
                             Configuration configuration) throws RemoteException {
        log.info("Fake starting " + id);
    }

    public void stopService(String id) throws RemoteException {
        log.info("Fake stopping " + id);
    }

    public Status getServiceStatus(String id) throws RemoteException {
        log.info("Faking status for " + id);
        return new Status(Status.CODE.running, "Fake status for " + id);
    }

    public List<String> getServices() throws RemoteException {
        log.info("Faking getServices");
        ArrayList<String> list = new ArrayList<String>(1);
        list.add("Fake ID");
        return list;
    }
}
